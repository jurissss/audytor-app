# Audytor – gotowy projekt do GitHub

Ten ZIP zawiera projekt Flutter bez zewnętrznego `audytor_app_mvp.zip`.

## Wgranie
1. Rozpakuj `Audytor_GitHub_gotowy.zip`.
2. Wgraj **zawartość** rozpakowanego katalogu do głównego katalogu repozytorium.
3. Upewnij się, że `.github/workflows/main.yml` znajduje się dokładnie w tej ścieżce.
4. Po commicie GitHub Actions uruchomi workflow `Audytor Android - SDK36`.
5. Po udanym buildzie APK będzie w artefakcie `Audytor-Android`.

Workflow instaluje Android SDK 36, wymusza compileSdk 36 również dla pluginów
i buduje `app-release.apk`.
