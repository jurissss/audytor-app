# Audytor App

Wersja 0.4.0.

Najważniejsze funkcje:
- obiekty z unikalnym numerem/kodem, wyszukiwaniem, edycją i usuwaniem,
- lista ostatnich audytów,
- audyty z usterkami i dokumentacją zdjęciową,
- zakończony audyt pozwala potwierdzić usunięcie każdej usterki,
- potwierdzenie usunięcia zapisuje datę, wymaga komentarza i opcjonalnie zdjęcia,
- potwierdzenie można później edytować lub cofnąć,
- PDF można wygenerować ponownie w dowolnym momencie; każda wersja zawiera aktualne statusy, daty, komentarze i zdjęcia po usunięciu usterek.
