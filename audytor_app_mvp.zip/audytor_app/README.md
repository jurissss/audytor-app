# Audytor – aplikacja mobilna do audytów

Pierwsza działająca wersja (MVP) aplikacji Flutter do wykonywania audytów technicznych.

## Co potrafi

- tworzenie i edycja obiektów,
- historia audytów dla każdego obiektu,
- rozpoczęcie audytu z nazwą audytora i typem audytu,
- automatyczne numery pozycji: `001`, `002`, `003`… (można je zmienić ręcznie),
- dodawanie usterek,
- obowiązkowy opis każdej usterki,
- obowiązkowe minimum jedno zdjęcie,
- zdjęcia z aparatu lub galerii,
- lokalizacja usterki,
- priorytet: niski / średni / wysoki / krytyczny,
- zalecenie / sposób naprawy,
- lokalny zapis w SQLite – aplikacja działa bez internetu,
- zakończenie audytu,
- generowanie raportu PDF,
- udostępnienie PDF do e-maila, komunikatora, Dysku itp.,
- drukowanie raportu przez system Android/iOS.

## Struktura danych

`Obiekt -> Audyt -> Usterka -> Zdjęcia`

Dane tekstowe są przechowywane lokalnie w bazie SQLite. Zdjęcia są kopiowane do katalogu danych aplikacji, dzięki czemu nie zależą później od pliku tymczasowego aparatu.

## Raport PDF

Raport zawiera:

1. stronę tytułową,
2. dane obiektu,
3. datę audytu,
4. audytora,
5. liczbę usterek i podział według priorytetu,
6. każdą usterkę jako osobną pozycję,
7. opis, lokalizację i zalecenie,
8. dokumentację zdjęciową.

Strony raportu są renderowane przez Flutter przed zapisaniem do PDF, dzięki czemu polskie znaki działają bez dołączania zewnętrznych plików fontów.

## Uruchomienie na komputerze

Wymagany jest Flutter 3.38 lub nowszy.

Po rozpakowaniu projektu wykonaj w jego katalogu:

```bash
flutter create . --platforms=android,ios
flutter pub get
flutter run
```

Dla Androida `image_picker` wymaga obecnie Android API 24+. Dołączone skrypty `.bat` oraz workflow GitHub ustawiają `minSdk = 24` automatycznie.

Jeżeli chcesz tylko Androida:

```bash
flutter create . --platforms=android
flutter pub get
flutter run
```

## Zbudowanie APK

```bash
flutter build apk --release
```

Gotowy plik znajdzie się tutaj:

`build/app/outputs/flutter-apk/app-release.apk`

## Automatyczne budowanie APK przez GitHub

W projekcie znajduje się workflow:

`.github/workflows/build-android.yml`

Po wrzuceniu projektu do repozytorium GitHub można ręcznie uruchomić akcję **Build Android APK**. GitHub utworzy plik APK jako artefakt zadania.

## Android

Pakiet `image_picker` korzysta z systemowego aparatu/selektora zdjęć. Po wykonaniu `flutter create .` standardowa konfiguracja Androida jest wystarczająca dla tego MVP.

## iOS

Dla iOS po `flutter create . --platforms=ios` należy dodać do `ios/Runner/Info.plist` opisy uprawnień aparatu i biblioteki zdjęć:

```xml
<key>NSCameraUsageDescription</key>
<string>Aplikacja potrzebuje aparatu do dokumentowania usterek podczas audytu.</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>Aplikacja potrzebuje dostępu do zdjęć, aby dodawać dokumentację usterek.</string>
```

## Następne sensowne rozszerzenia

- baza obiektów synchronizowana z chmurą,
- logowanie audytorów,
- panel www dla biura,
- podpis klienta na ekranie,
- lista urządzeń przypisana do obiektu,
- kategorie usterek,
- kopiowanie usterek z poprzedniego audytu jako „nadal występuje”,
- status „naprawiona / nadal występuje / nie sprawdzono”,
- eksport do Excel,
- własne logo i firmowy szablon PDF,
- wysyłanie raportu automatycznie po zakończeniu audytu.
