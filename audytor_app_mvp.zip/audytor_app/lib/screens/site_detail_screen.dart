import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/audit.dart';
import '../models/site.dart';
import '../services/database_service.dart';
import '../services/photo_service.dart';
import '../widgets/empty_state.dart';
import 'audit_screen.dart';
import 'audit_setup_screen.dart';
import 'site_form_screen.dart';

class SiteDetailScreen extends StatefulWidget {
  final Site site;

  const SiteDetailScreen({super.key, required this.site});

  @override
  State<SiteDetailScreen> createState() => _SiteDetailScreenState();
}

class _SiteDetailScreenState extends State<SiteDetailScreen> {
  late Site _site;
  bool _loading = true;
  List<Audit> _audits = [];
  final Map<int, int> _defectCounts = {};

  @override
  void initState() {
    super.initState();
    _site = widget.site;
    _load();
  }

  Future<void> _load() async {
    final audits = await DatabaseService.instance.getAuditsForSite(_site.id!);
    final counts = <int, int>{};
    for (final audit in audits) {
      if (audit.id != null) {
        counts[audit.id!] = await DatabaseService.instance.countDefects(audit.id!);
      }
    }
    if (!mounted) return;
    setState(() {
      _audits = audits;
      _defectCounts
        ..clear()
        ..addAll(counts);
      _loading = false;
    });
  }

  Future<void> _startAudit() async {
    final audit = await Navigator.of(context).push<Audit>(
      MaterialPageRoute(builder: (_) => AuditSetupScreen(site: _site)),
    );
    if (audit == null || !mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => AuditScreen(site: _site, audit: audit)),
    );
    await _load();
  }

  Future<void> _editSite() async {
    final changed = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => SiteFormScreen(site: _site)),
    );
    if (changed == true && mounted) {
      final sites = await DatabaseService.instance.getSites();
      final fresh = sites.where((e) => e.id == _site.id).firstOrNull;
      if (fresh != null) setState(() => _site = fresh);
    }
  }

  Future<void> _deleteSite() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Usunąć obiekt?'),
        content: const Text('Usunięte zostaną także wszystkie audyty, usterki i wpisy zdjęć tego obiektu.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Anuluj')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Usuń')),
        ],
      ),
    );
    if (confirmed != true) return;
    final photoPaths = await DatabaseService.instance.getPhotoPathsForSite(_site.id!);
    for (final path in photoPaths) {
      await PhotoService.deleteIfExists(path);
    }
    await DatabaseService.instance.deleteSite(_site.id!);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_site.name),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'edit') _editSite();
              if (value == 'delete') _deleteSite();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'edit', child: Text('Edytuj obiekt')),
              PopupMenuItem(value: 'delete', child: Text('Usuń obiekt')),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _startAudit,
        icon: const Icon(Icons.playlist_add_check_circle_outlined),
        label: const Text('Nowy audyt'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 110),
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_site.name, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                          if (_site.code.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Text('Nr / kod: ${_site.code}'),
                          ],
                          if (_site.address.isNotEmpty) ...[
                            const SizedBox(height: 6),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Icon(Icons.location_on_outlined, size: 18),
                                const SizedBox(width: 6),
                                Expanded(child: Text(_site.address)),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  Text('Audyty', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),
                  if (_audits.isEmpty)
                    SizedBox(
                      height: 380,
                      child: EmptyState(
                        icon: Icons.fact_check_outlined,
                        title: 'Brak audytów',
                        subtitle: 'Rozpocznij pierwszy audyt dla tego obiektu.',
                        buttonLabel: 'Nowy audyt',
                        onPressed: _startAudit,
                      ),
                    )
                  else
                    ..._audits.map((audit) => Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Card(
                            child: ListTile(
                              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                              leading: CircleAvatar(
                                child: Icon(audit.isCompleted ? Icons.check : Icons.edit_note),
                              ),
                              title: Text(audit.auditType, style: const TextStyle(fontWeight: FontWeight.w700)),
                              subtitle: Text(
                                '${DateFormat('dd.MM.yyyy HH:mm').format(audit.startedAt)} • '
                                '${_defectCounts[audit.id] ?? 0} usterek • '
                                '${audit.isCompleted ? 'Zakończony' : 'Roboczy'}',
                              ),
                              trailing: const Icon(Icons.chevron_right),
                              onTap: () async {
                                await Navigator.of(context).push(
                                  MaterialPageRoute(builder: (_) => AuditScreen(site: _site, audit: audit)),
                                );
                                await _load();
                              },
                            ),
                          ),
                        )),
                ],
              ),
            ),
    );
  }
}

extension _FirstOrNullExtension<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
