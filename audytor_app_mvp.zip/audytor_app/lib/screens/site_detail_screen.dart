import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/audit.dart';
import '../models/defect.dart';
import '../models/site.dart';
import '../services/database_service.dart';
import '../services/photo_service.dart';
import '../widgets/empty_state.dart';
import 'audit_screen.dart';
import 'audit_setup_screen.dart';
import 'site_form_screen.dart';

class SiteDetailScreen extends StatefulWidget {
  final Site site;

  const SiteDetailScreen({super.key, required this.site});

  @override
  State<SiteDetailScreen> createState() => _SiteDetailScreenState();
}

class _SiteDetailScreenState extends State<SiteDetailScreen> {
  late Site _site;
  bool _loading = true;
  bool _creatingReaudit = false;
  List<Audit> _audits = [];
  final Map<int, int> _defectCounts = {};
  final Map<int, int> _resolvedCounts = {};

  @override
  void initState() {
    super.initState();
    _site = widget.site;
    _load();
  }

  Future<void> _load() async {
    final audits = await DatabaseService.instance.getAuditsForSite(_site.id!);
    final counts = <int, int>{};
    final resolved = <int, int>{};
    for (final audit in audits) {
      if (audit.id != null) {
        counts[audit.id!] = await DatabaseService.instance.countDefects(audit.id!);
        resolved[audit.id!] = await DatabaseService.instance.countResolvedDefects(audit.id!);
      }
    }
    if (!mounted) return;
    setState(() {
      _audits = audits;
      _defectCounts
        ..clear()
        ..addAll(counts);
      _resolvedCounts
        ..clear()
        ..addAll(resolved);
      _loading = false;
    });
  }

  Future<void> _startAudit() async {
    final audit = await Navigator.of(context).push<Audit>(
      MaterialPageRoute(builder: (_) => AuditSetupScreen(site: _site)),
    );
    if (audit == null || !mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => AuditScreen(site: _site, audit: audit)),
    );
    await _load();
  }

  Future<void> _startReaudit(Audit sourceAudit) async {
    if (_creatingReaudit || sourceAudit.id == null) return;

    final audit = await Navigator.of(context).push<Audit>(
      MaterialPageRoute(
        builder: (_) => AuditSetupScreen(
          site: _site,
          title: 'Rozpocznij reaudyt',
          buttonLabel: 'Rozpocznij reaudyt',
          initialAuditor: sourceAudit.auditor,
          initialType: 'Reaudyt – ${sourceAudit.auditType}',
          initialNotes: 'Reaudyt audytu z ${DateFormat('dd.MM.yyyy').format(sourceAudit.startedAt)}',
          parentAuditId: sourceAudit.id,
        ),
      ),
    );
    if (audit == null || !mounted) return;

    setState(() => _creatingReaudit = true);
    try {
      final sourceDefects = await DatabaseService.instance.getDefectsForAudit(sourceAudit.id!);
      for (final source in sourceDefects) {
        final copied = Defect(
          auditId: audit.id!,
          positionNo: source.positionNo,
          location: source.location,
          description: source.description,
          priority: source.priority,
          recommendation: source.recommendation,
          createdAt: DateTime.now(),
          sourceDefectId: source.id,
          isResolved: false,
        );
        final newDefectId = await DatabaseService.instance.insertDefect(copied);

        if (source.id != null) {
          final oldPhotos = await DatabaseService.instance.getPhotosForDefect(source.id!);
          final copiedPaths = <String>[];
          for (final photo in oldPhotos) {
            try {
              copiedPaths.add(await PhotoService.clonePersistedFile(photo.path));
            } catch (_) {
              // Brak pojedynczego starego zdjęcia nie blokuje całego reaudytu.
            }
          }
          await DatabaseService.instance.replacePhotos(newDefectId, copiedPaths);
        }
      }

      if (!mounted) return;
      setState(() => _creatingReaudit = false);
      await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => AuditScreen(site: _site, audit: audit)),
      );
      await _load();
    } catch (e) {
      if (!mounted) return;
      setState(() => _creatingReaudit = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Nie udało się przygotować reaudytu: $e')),
      );
    }
  }

  Future<void> _editSite() async {
    final changed = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => SiteFormScreen(site: _site)),
    );
    if (changed == true && mounted) {
      final fresh = await DatabaseService.instance.getSiteById(_site.id!);
      if (fresh != null) setState(() => _site = fresh);
    }
  }

  Future<void> _deleteSite() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Usunąć obiekt?'),
        content: const Text(
          'Usunięte zostaną także wszystkie audyty, reaudyt, usterki i wpisy zdjęć tego obiektu.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Anuluj')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Usuń')),
        ],
      ),
    );
    if (confirmed != true) return;
    final photoPaths = await DatabaseService.instance.getPhotoPathsForSite(_site.id!);
    for (final path in photoPaths) {
      await PhotoService.deleteIfExists(path);
    }
    await DatabaseService.instance.deleteSite(_site.id!);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_site.name),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'edit') _editSite();
              if (value == 'delete') _deleteSite();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'edit', child: Text('Edytuj obiekt')),
              PopupMenuItem(value: 'delete', child: Text('Usuń obiekt')),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _creatingReaudit ? null : _startAudit,
        icon: const Icon(Icons.playlist_add_check_circle_outlined),
        label: const Text('Nowy audyt'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 110),
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _site.name,
                            style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
                          ),
                          if (_site.code.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Text('Nr / kod: ${_site.code}'),
                          ],
                          if (_site.address.isNotEmpty) ...[
                            const SizedBox(height: 6),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Icon(Icons.location_on_outlined, size: 18),
                                const SizedBox(width: 6),
                                Expanded(child: Text(_site.address)),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  Text(
                    'Audyty',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 10),
                  if (_audits.isEmpty)
                    SizedBox(
                      height: 380,
                      child: EmptyState(
                        icon: Icons.fact_check_outlined,
                        title: 'Brak audytów',
                        subtitle: 'Rozpocznij pierwszy audyt dla tego obiektu.',
                        buttonLabel: 'Nowy audyt',
                        onPressed: _startAudit,
                      ),
                    )
                  else
                    ..._audits.map((audit) {
                      final total = _defectCounts[audit.id] ?? 0;
                      final resolved = _resolvedCounts[audit.id] ?? 0;
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Card(
                          child: Column(
                            children: [
                              ListTile(
                                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                leading: CircleAvatar(
                                  child: Icon(
                                    audit.isReaudit
                                        ? Icons.replay
                                        : audit.isCompleted
                                            ? Icons.check
                                            : Icons.edit_note,
                                  ),
                                ),
                                title: Text(
                                  audit.auditType,
                                  style: const TextStyle(fontWeight: FontWeight.w700),
                                ),
                                subtitle: Text(
                                  '${DateFormat('dd.MM.yyyy HH:mm').format(audit.startedAt)} • '
                                  '$resolved/$total wykonane • '
                                  '${audit.isCompleted ? 'Zakończony' : 'Roboczy'}',
                                ),
                                trailing: const Icon(Icons.chevron_right),
                                onTap: () async {
                                  await Navigator.of(context).push(
                                    MaterialPageRoute(builder: (_) => AuditScreen(site: _site, audit: audit)),
                                  );
                                  await _load();
                                },
                              ),
                              if (audit.isCompleted)
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                                  child: SizedBox(
                                    width: double.infinity,
                                    child: FilledButton.tonalIcon(
                                      onPressed: _creatingReaudit ? null : () => _startReaudit(audit),
                                      icon: const Icon(Icons.replay),
                                      label: const Text('Wykonaj reaudyt'),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      );
                    }),
                ],
              ),
            ),
    );
  }
}
