import 'package:flutter/material.dart';

import '../models/site.dart';
import '../services/database_service.dart';
import '../widgets/empty_state.dart';
import 'site_detail_screen.dart';
import 'site_form_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _loading = true;
  List<Site> _sites = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final sites = await DatabaseService.instance.getSites();
    if (!mounted) return;
    setState(() {
      _sites = sites;
      _loading = false;
    });
  }

  Future<void> _addSite() async {
    final changed = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const SiteFormScreen()),
    );
    if (changed == true) await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Audytor', style: TextStyle(fontWeight: FontWeight.w700)),
            Text('Obiekty', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w400)),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addSite,
        icon: const Icon(Icons.add_business),
        label: const Text('Dodaj obiekt'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: _sites.isEmpty
                  ? ListView(
                      children: [
                        SizedBox(
                          height: MediaQuery.sizeOf(context).height * 0.68,
                          child: EmptyState(
                            icon: Icons.apartment_rounded,
                            title: 'Nie ma jeszcze obiektów',
                            subtitle: 'Dodaj pierwszy obiekt, aby rozpocząć audyt.',
                            buttonLabel: 'Dodaj obiekt',
                            onPressed: _addSite,
                          ),
                        ),
                      ],
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 110),
                      itemCount: _sites.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final site = _sites[index];
                        return Card(
                          child: ListTile(
                            contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                            leading: CircleAvatar(
                              backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                              child: const Icon(Icons.factory_outlined),
                            ),
                            title: Text(site.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                            subtitle: Text([
                              if (site.code.isNotEmpty) site.code,
                              if (site.address.isNotEmpty) site.address,
                            ].join(' • ')),
                            trailing: const Icon(Icons.chevron_right),
                            onTap: () async {
                              await Navigator.of(context).push(
                                MaterialPageRoute(builder: (_) => SiteDetailScreen(site: site)),
                              );
                              await _load();
                            },
                          ),
                        );
                      },
                    ),
            ),
    );
  }
}
