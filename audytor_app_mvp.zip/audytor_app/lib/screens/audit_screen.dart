import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/audit.dart';
import '../models/audit_photo.dart';
import '../models/defect.dart';
import '../models/site.dart';
import '../services/database_service.dart';
import '../services/photo_service.dart';
import '../services/report_service.dart';
import '../widgets/empty_state.dart';
import 'defect_detail_screen.dart';
import 'defect_form_screen.dart';

class AuditScreen extends StatefulWidget {
  final Site site;
  final Audit audit;

  const AuditScreen({super.key, required this.site, required this.audit});

  @override
  State<AuditScreen> createState() => _AuditScreenState();
}

class _AuditScreenState extends State<AuditScreen> {
  late Audit _audit;
  bool _loading = true;
  bool _generating = false;
  List<Defect> _defects = [];
  final Map<int, List<AuditPhoto>> _photos = {};

  @override
  void initState() {
    super.initState();
    _audit = widget.audit;
    _load();
  }

  Future<void> _load() async {
    final defects = await DatabaseService.instance.getDefectsForAudit(_audit.id!);
    final photos = await DatabaseService.instance.getPhotosForDefects(defects);
    if (!mounted) return;
    setState(() {
      _defects = defects;
      _photos
        ..clear()
        ..addAll(photos);
      _loading = false;
    });
  }

  Future<void> _addDefect() async {
    final next = await DatabaseService.instance.getNextPositionNo(_audit.id!);
    if (!mounted) return;
    final changed = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => DefectFormScreen(
          auditId: _audit.id!,
          suggestedPosition: next,
        ),
      ),
    );
    if (changed == true) await _load();
  }

  Future<void> _editDefect(Defect defect) async {
    final changed = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => DefectFormScreen(
          auditId: _audit.id!,
          suggestedPosition: defect.positionNo,
          defect: defect,
          initialPhotos: _photos[defect.id] ?? const [],
        ),
      ),
    );
    if (changed == true) await _load();
  }

  Future<void> _deleteDefect(Defect defect) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Usunąć pozycję ${defect.positionNo}?'),
        content: const Text('Usterka i jej zdjęcia zostaną usunięte z audytu.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Anuluj')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Usuń')),
        ],
      ),
    );
    if (yes != true) return;
    for (final photo in _photos[defect.id] ?? const <AuditPhoto>[]) {
      await PhotoService.deleteIfExists(photo.path);
    }
    await DatabaseService.instance.deleteDefect(defect.id!);
    await _load();
  }

  Future<void> _toggleResolved(Defect defect, bool resolved) async {
    if (_audit.isCompleted || defect.id == null) return;
    await DatabaseService.instance.setDefectResolved(defect.id!, resolved);
    await _load();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        duration: const Duration(seconds: 1),
        content: Text(
          resolved
              ? 'Pozycja ${defect.positionNo}: potwierdzono wykonanie.'
              : 'Pozycja ${defect.positionNo}: cofnięto potwierdzenie.',
        ),
      ),
    );
  }

  Future<void> _complete() async {
    final resolved = _defects.where((d) => d.isResolved).length;
    final open = _defects.length - resolved;
    final yes = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Zakończyć audyt?'),
        content: Text(
          'Audyt zawiera ${_defects.length} usterek. '
          'Potwierdzone jako wykonane: $resolved. Pozostałe: $open. '
          'Po zakończeniu nadal będzie można wygenerować raport PDF.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Anuluj')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Zakończ')),
        ],
      ),
    );
    if (yes != true) return;

    final completed = _audit.copyWith(
      status: 'completed',
      completedAt: DateTime.now(),
    );
    await DatabaseService.instance.updateAudit(completed);
    if (!mounted) return;
    setState(() => _audit = completed);
  }

  Future<void> _generateReport() async {
    setState(() => _generating = true);
    try {
      final report = await ReportService.generate(
        site: widget.site,
        audit: _audit,
        defects: _defects,
        photos: _photos,
      );
      if (!mounted) return;
      setState(() => _generating = false);
      await showModalBottomSheet<void>(
        context: context,
        showDragHandle: true,
        builder: (context) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'Raport PDF gotowy',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                Text(report.filename),
                const SizedBox(height: 4),
                Text('Zapisano lokalnie w pamięci aplikacji.', style: Theme.of(context).textTheme.bodySmall),
                const SizedBox(height: 18),
                FilledButton.icon(
                  onPressed: () => ReportService.share(report),
                  icon: const Icon(Icons.share_outlined),
                  label: const Text('Udostępnij PDF'),
                ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: () => ReportService.printReport(report),
                  icon: const Icon(Icons.print_outlined),
                  label: const Text('Drukuj / zapisz jako PDF'),
                ),
              ],
            ),
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _generating = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Nie udało się wygenerować raportu: $e')),
      );
    }
  }

  Color _priorityColor(String priority, ColorScheme scheme) {
    return switch (priority) {
      'Krytyczny' => scheme.error,
      'Wysoki' => Colors.orange.shade800,
      'Niski' => Colors.green.shade700,
      _ => scheme.primary,
    };
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final resolvedCount = _defects.where((d) => d.isResolved).length;
    final openCount = _defects.length - resolvedCount;

    return Scaffold(
      appBar: AppBar(
        title: Text(_audit.isReaudit ? 'Reaudyt' : 'Audyt'),
        actions: [
          IconButton(
            tooltip: 'Generuj PDF',
            onPressed: _generating ? null : _generateReport,
            icon: const Icon(Icons.picture_as_pdf_outlined),
          ),
        ],
      ),
      floatingActionButton: _audit.isCompleted
          ? null
          : FloatingActionButton.extended(
              onPressed: _addDefect,
              icon: const Icon(Icons.add),
              label: const Text('Dodaj usterkę'),
            ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 110),
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      widget.site.name,
                                      style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(_audit.auditType),
                                  ],
                                ),
                              ),
                              Chip(
                                avatar: Icon(_audit.isCompleted ? Icons.check_circle : Icons.edit_note, size: 18),
                                label: Text(_audit.isCompleted ? 'Zakończony' : 'Roboczy'),
                              ),
                            ],
                          ),
                          if (_audit.isReaudit) ...[
                            const SizedBox(height: 10),
                            const Chip(
                              avatar: Icon(Icons.replay, size: 18),
                              label: Text('Reaudyt poprzedniego audytu'),
                            ),
                          ],
                          const Divider(height: 28),
                          _InfoRow(icon: Icons.person_outline, text: _audit.auditor),
                          const SizedBox(height: 8),
                          _InfoRow(
                            icon: Icons.schedule,
                            text: DateFormat('dd.MM.yyyy HH:mm').format(_audit.startedAt),
                          ),
                          if (_audit.notes.isNotEmpty) ...[
                            const SizedBox(height: 12),
                            Text(_audit.notes),
                          ],
                          const SizedBox(height: 16),
                          Row(
                            children: [
                              Expanded(child: _SummaryBox(label: 'Wykonane', value: '$resolvedCount', icon: Icons.task_alt)),
                              const SizedBox(width: 10),
                              Expanded(child: _SummaryBox(label: 'Pozostałe', value: '$openCount', icon: Icons.pending_actions)),
                            ],
                          ),
                          const SizedBox(height: 18),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: [
                              FilledButton.tonalIcon(
                                onPressed: _generating ? null : _generateReport,
                                icon: _generating
                                    ? const SizedBox.square(
                                        dimension: 18,
                                        child: CircularProgressIndicator(strokeWidth: 2),
                                      )
                                    : const Icon(Icons.picture_as_pdf_outlined),
                                label: Text(_generating ? 'Tworzenie PDF…' : 'Raport PDF'),
                              ),
                              if (!_audit.isCompleted)
                                OutlinedButton.icon(
                                  onPressed: _complete,
                                  icon: const Icon(Icons.task_alt),
                                  label: const Text('Zakończ audyt'),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Usterki',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                        ),
                      ),
                      Text('${_defects.length}'),
                    ],
                  ),
                  const SizedBox(height: 10),
                  if (_defects.isEmpty)
                    SizedBox(
                      height: 380,
                      child: EmptyState(
                        icon: Icons.report_gmailerrorred_outlined,
                        title: 'Brak usterek',
                        subtitle: _audit.isCompleted
                            ? 'W tym audycie nie dodano usterek.'
                            : 'Dodaj usterkę wraz z opisem i co najmniej jednym zdjęciem.',
                        buttonLabel: _audit.isCompleted ? null : 'Dodaj usterkę',
                        onPressed: _audit.isCompleted ? null : _addDefect,
                      ),
                    )
                  else
                    ..._defects.map((defect) {
                      final defectPhotos = _photos[defect.id] ?? const <AuditPhoto>[];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Card(
                          child: Padding(
                            padding: const EdgeInsets.all(14),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                InkWell(
                                  borderRadius: BorderRadius.circular(14),
                                  onTap: () => Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (_) => DefectDetailScreen(defect: defect, photos: defectPhotos),
                                    ),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(12),
                                        child: defectPhotos.isNotEmpty && File(defectPhotos.first.path).existsSync()
                                            ? Image.file(
                                                File(defectPhotos.first.path),
                                                width: 86,
                                                height: 86,
                                                fit: BoxFit.cover,
                                              )
                                            : Container(
                                                width: 86,
                                                height: 86,
                                                color: scheme.surfaceContainerHighest,
                                                child: const Icon(Icons.image_not_supported_outlined),
                                              ),
                                      ),
                                      const SizedBox(width: 14),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: Text(
                                                    'Pozycja ${defect.positionNo}',
                                                    style: const TextStyle(fontWeight: FontWeight.w800),
                                                  ),
                                                ),
                                                Container(
                                                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                                                  decoration: BoxDecoration(
                                                    color: _priorityColor(defect.priority, scheme).withOpacity(0.12),
                                                    borderRadius: BorderRadius.circular(999),
                                                  ),
                                                  child: Text(
                                                    defect.priority,
                                                    style: TextStyle(
                                                      color: _priorityColor(defect.priority, scheme),
                                                      fontSize: 12,
                                                      fontWeight: FontWeight.w700,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            if (defect.inheritedFromPreviousAudit) ...[
                                              const SizedBox(height: 5),
                                              Text(
                                                'Z poprzedniego audytu',
                                                style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w700),
                                              ),
                                            ],
                                            if (defect.location.isNotEmpty) ...[
                                              const SizedBox(height: 4),
                                              Text(defect.location, style: Theme.of(context).textTheme.bodySmall),
                                            ],
                                            const SizedBox(height: 5),
                                            Text(defect.description, maxLines: 2, overflow: TextOverflow.ellipsis),
                                            const SizedBox(height: 7),
                                            Text(
                                              '${defectPhotos.length} ${defectPhotos.length == 1 ? 'zdjęcie' : 'zdjęć'}',
                                              style: Theme.of(context).textTheme.bodySmall,
                                            ),
                                          ],
                                        ),
                                      ),
                                      if (!_audit.isCompleted)
                                        PopupMenuButton<String>(
                                          onSelected: (value) {
                                            if (value == 'edit') _editDefect(defect);
                                            if (value == 'delete') _deleteDefect(defect);
                                          },
                                          itemBuilder: (_) => const [
                                            PopupMenuItem(value: 'edit', child: Text('Edytuj')),
                                            PopupMenuItem(value: 'delete', child: Text('Usuń')),
                                          ],
                                        ),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 10),
                                const Divider(height: 1),
                                const SizedBox(height: 8),
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        defect.isResolved ? 'Usterka wykonana' : 'Usterka do wykonania',
                                        style: TextStyle(
                                          fontWeight: FontWeight.w700,
                                          color: defect.isResolved ? Colors.green.shade700 : scheme.onSurfaceVariant,
                                        ),
                                      ),
                                    ),
                                    FilterChip(
                                      selected: defect.isResolved,
                                      onSelected: _audit.isCompleted
                                          ? null
                                          : (value) => _toggleResolved(defect, value),
                                      avatar: Icon(
                                        defect.isResolved ? Icons.check_circle : Icons.radio_button_unchecked,
                                        size: 18,
                                      ),
                                      label: Text(defect.isResolved ? 'Potwierdzone' : 'Potwierdź wykonanie'),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    }),
                ],
              ),
            ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String text;

  const _InfoRow({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 18),
        const SizedBox(width: 8),
        Expanded(child: Text(text)),
      ],
    );
  }
}

class _SummaryBox extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _SummaryBox({required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withOpacity(0.55),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Icon(icon, size: 20),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
              Text(label, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ],
      ),
    );
  }
}
