import 'dart:io';

import 'package:flutter/material.dart';

import '../models/audit_photo.dart';
import '../models/defect.dart';

class DefectDetailScreen extends StatelessWidget {
  final Defect defect;
  final List<AuditPhoto> photos;

  const DefectDetailScreen({super.key, required this.defect, required this.photos});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Pozycja ${defect.positionNo}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: Text('Pozycja ${defect.positionNo}', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700))),
                      Chip(label: Text(defect.priority)),
                    ],
                  ),
                  if (defect.location.isNotEmpty) ...[
                    const SizedBox(height: 14),
                    const Text('Lokalizacja', style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text(defect.location),
                  ],
                  const SizedBox(height: 14),
                  const Text('Opis usterki', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text(defect.description),
                  if (defect.recommendation.isNotEmpty) ...[
                    const SizedBox(height: 14),
                    const Text('Zalecenie', style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text(defect.recommendation),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          Text('Zdjęcia (${photos.length})', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          ...photos.map((photo) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.file(File(photo.path), fit: BoxFit.cover),
                ),
              )),
        ],
      ),
    );
  }
}
