class Defect {
  final int? id;
  final int auditId;
  final String positionNo;
  final String location;
  final String description;
  final String priority;
  final String recommendation;
  final DateTime createdAt;

  const Defect({
    this.id,
    required this.auditId,
    required this.positionNo,
    required this.location,
    required this.description,
    required this.priority,
    required this.recommendation,
    required this.createdAt,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'audit_id': auditId,
        'position_no': positionNo,
        'location': location,
        'description': description,
        'priority': priority,
        'recommendation': recommendation,
        'created_at': createdAt.toIso8601String(),
      };

  factory Defect.fromMap(Map<String, Object?> map) => Defect(
        id: map['id'] as int?,
        auditId: map['audit_id'] as int,
        positionNo: map['position_no'] as String,
        location: (map['location'] as String?) ?? '',
        description: map['description'] as String,
        priority: (map['priority'] as String?) ?? 'Średni',
        recommendation: (map['recommendation'] as String?) ?? '',
        createdAt: DateTime.parse(map['created_at'] as String),
      );
}
