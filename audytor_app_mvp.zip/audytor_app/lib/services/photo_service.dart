import 'dart:io';

import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class PhotoService {
  static final ImagePicker _picker = ImagePicker();

  static Future<XFile?> takePhoto() {
    return _picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 85,
      maxWidth: 2200,
    );
  }

  static Future<List<XFile>> pickFromGallery() {
    return _picker.pickMultiImage(
      imageQuality: 85,
      maxWidth: 2200,
    );
  }

  static Future<String> persistPickedFile(XFile source) async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'audit_photos'));
    if (!await dir.exists()) await dir.create(recursive: true);

    final ext = p.extension(source.path).isEmpty ? '.jpg' : p.extension(source.path);
    final filename = 'photo_${DateTime.now().microsecondsSinceEpoch}$ext';
    final target = File(p.join(dir.path, filename));
    await File(source.path).copy(target.path);
    return target.path;
  }

  static Future<String> clonePersistedFile(String sourcePath) async {
    final source = File(sourcePath);
    if (!await source.exists()) {
      throw StateError('Brak pliku zdjęcia: $sourcePath');
    }

    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'audit_photos'));
    if (!await dir.exists()) await dir.create(recursive: true);

    final ext = p.extension(sourcePath).isEmpty ? '.jpg' : p.extension(sourcePath);
    final filename = 'photo_${DateTime.now().microsecondsSinceEpoch}$ext';
    final target = File(p.join(dir.path, filename));
    await source.copy(target.path);
    return target.path;
  }

  static Future<void> deleteIfExists(String path) async {
    final file = File(path);
    if (await file.exists()) {
      await file.delete();
    }
  }
}
